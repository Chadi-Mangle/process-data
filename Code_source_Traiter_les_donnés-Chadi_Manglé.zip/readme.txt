Dans le cadre de la SAE 15, traiter les données, on devait réaliser à partir d'un fichier csv un site web 
avec un tableau contenant des données du fichier CSV. J'ai donc choisi de prendre une base de données sur la fibre optique.
A partir de ces données j'ai fait plusieurs calculs, addition, taux de croissance, prédictions, moyenne et pourcentage. 
Une fois les données traitées et stockées, en python j'ai créé un tableau contenant ces données. Grâce à cette SAE, 
nous avons pu mettre en pratique nos compétences en python et en développement web pour créer un outil utile et fonctionnel.


Lien vers le site: https://chadi-mangle.github.io/process-data/

